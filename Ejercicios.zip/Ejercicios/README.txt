Nuestro grupo está compuesto por:

José Casal Fernández
José Luis López Sánchez

