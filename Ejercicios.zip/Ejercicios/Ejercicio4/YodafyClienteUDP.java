//
// YodafyServidorIterativo
// (CC) jjramos, 2012
//
import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.UnknownHostException;

public class YodafyClienteUDP {
	public static void main(String[] args) {
		// Puerto en el que espera el servidor:
		int port = 8989;
		// Socket y Datagramas para la conexión UDP
		DatagramSocket socket = null;
		DatagramPacket paqueteOriginal = null,
					   paqueteModificado = null;
		// Dirección del Servidor
		InetAddress direccion = null;
		// Bufers para el envio y recepción de los datos
		byte[] buferEnvio = new byte[256],
			   buferRecepcion = new byte[256];

		try {
			// Vamos a crear el socket para la comunicación de datagramas
			socket = new DatagramSocket();

			// Obtenemos la dirección a donde nos vamos a conectar
			direccion = InetAddress.getByName("localhost");

			// Enviamos el mensaje al servidor
			buferEnvio = "Al monte del volcan debes ir sin demora".getBytes();
            paqueteOriginal = new DatagramPacket(buferEnvio, buferEnvio.length, direccion, port);
            socket.send(paqueteOriginal);

			// Recibimos la respuesta modificada del servidor
            paqueteModificado = new DatagramPacket(buferRecepcion, buferRecepcion.length);
			socket.receive(paqueteModificado);
			
			// Imprimimos el mensaje en pantalla
			String fraseYoda = new String(paqueteModificado.getData());
			System.out.println("\nRecibido: " + fraseYoda + "\n");
			
			// Cerramos el socket
			socket.close();
		} catch (UnknownHostException e) {
			System.err.println("Error al recuperar la dirección.");
		} catch (IOException e) {
            System.err.println("Error de entrada/salida al abrir el socket.");
        }
	}
}
